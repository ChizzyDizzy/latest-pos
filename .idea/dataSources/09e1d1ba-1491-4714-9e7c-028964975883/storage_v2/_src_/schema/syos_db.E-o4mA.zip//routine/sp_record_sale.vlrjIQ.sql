create
    definer = root@localhost procedure sp_record_sale(IN p_bill_number bigint, IN p_item_code varchar(20), IN p_quantity int)
BEGIN
    -- Update item quantity
    UPDATE items
    SET quantity = quantity - p_quantity
    WHERE code = p_item_code;

    -- Record stock movement
    INSERT INTO stock_movements (item_code, movement_type, quantity, from_state, to_state, notes)
    VALUES (p_item_code, 'SALE', p_quantity, 'ON_SHELF', 'ON_SHELF', CONCAT('Bill #', p_bill_number));
END;

